package com.generated.sdk;

public class productClient {
    private String baseUrl;

    public productClient(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String hello() {
        return "Hello from Java SDK";
    }
}
